################### LIB-S #######################################
require(ggplot2)
require(tseries)
require(tsibble)
require(fpp3)
require(foreach)

################### FUN-S #######################################


################### MAIN ########################################

# Get data 1972-
five_lakes_data_ts <- LakeHuron
first_dif_5ld <- diff(five_lakes_data_ts, differences = 1)

#Get data 1972+
huron_df <- read.csv("evaporation_hur.csv")

#------------------ Data manipulation -----------------------

# TS
five_lakes_data_df <- as.data.frame(LakeHuron)
five_lakes_data_df$Year <- c(1875:1972)

# 1st differences
first_dif_5ld_df <- as.data.frame(first_dif_5ld)
first_dif_5ld_df$Year <- c(1876:1972)

#Huron 1972+
huron_df_1972 <- huron_df[huron_df$YYYY > 1972,]


#------------------ Plot data -------------------------------

# TS
ggplot(five_lakes_data_df, aes(x = Year, y = x)) +
  geom_line() +
  geom_smooth()+
  labs(subtitle = "Level of Huron")


# 1st differences
ggplot(first_dif_5ld_df, aes(x = Year, y = x)) +
  geom_line() +
  geom_smooth()+
  labs(subtitle = "1st differences series")

#------------------ Explore data -----------------------------

# TS
adf.test(five_lakes_data_ts) #non stationary
kpss.test(five_lakes_data_ts) #non stationary

# 1st differences
adf.test(diff(five_lakes_data_ts, differences = 1)) #stationary
kpss.test(diff(five_lakes_data_ts, differences = 1)) #stationary

#ACF
acf(five_lakes_data_ts)
acf(first_dif_5ld)

#------------------ Decomposition ----------------------------
dcmp_stl <- as_tsibble(five_lakes_data_ts) %>% 
  model(stl=STL(value))
components(dcmp_stl) %>% 
  autoplot()

#------------------ T-Strength -------------------------------

as_tsibble(five_lakes_data_ts) %>% 
  features(value, feat_stl)

# T-strength = 0.798


#------------------ Models ----------------------------------

# LM
fit_lm <- lm(data = five_lakes_data_df, x~I(Year^2)+Year)
summary(fit_lm)

# ETS
fit_ets <- as_tsibble(five_lakes_data_ts) %>% 
  model(ETS(value~error("A")+trend("A")+season("N"))) %>% 
  report()

# ARIMA
fit_arima <-  as_tsibble(five_lakes_data_ts)%>% 
  model(
    #auto = ARIMA(value,stepwise = FALSE,approx = FALSE),
    own = ARIMA(value ~ pdq(2,1,1))
  )

fit_arima %>% pivot_longer(everything(),names_to = "Model name",
                     values_to = "Orders")
glance(fit_arima) %>%
  arrange(AICc) %>%
  select(.model:BIC)

#------------------ Plot models ----------------------------

# LM
plot1 <- ggplot(five_lakes_data_df, aes(x = Year, y = x)) +
  geom_line() +
  labs(subtitle = "Owr model")

(plot2 <- plot1 + 
    geom_smooth(method = "loess") +
    geom_line(aes(x=Year, y=fit_lm$fitted.values), col="gold", lwd = 1))


#------------------ Forecast --------------------------------

# ARIMA
fit_arima %>% forecast(h = 3) %>% 
  autoplot(five_lakes_data_ts)+
  labs(title = "ARIMA 2_1_1 FORECAST")

#ETS
fit_ets %>% forecast(h = 3) %>% 
  autoplot(five_lakes_data_ts)+
  labs(title = "ETS(A,A,N) FORECAST")

#LM
new_data <- data.frame(Year = c(1973:1975))
forecast_values <- predict(fit_lm, newdata = new_data)




